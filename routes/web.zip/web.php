<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/','HomeController@index');


// ====== EventController =========
Route::get('/single_event','EventController@single_event')->name('single_event');
Route::get('/m_events','EventController@m_events')->name('m_events');



// ====== SeatController =======
Route::get('/seat_section','SeatController@seat_section')->name('seat_section');
Route::get('/seats','SeatController@seats')->name('seats');
Route::get('/myseat','SeatController@myseat')->name('myseat');



// ===== TicketingController =======
Route::get('/section_select','TicketingController@section_select')->name('section_select');
Route::get('/prepay_ticket','TicketingController@prepay_ticket')->name('prepay_ticket');
Route::get('/final_ticket','TicketingController@final_ticket')->name('final_ticket');

// ======== SiteController ======
Route::get('/tracking','SiteController@tracking')->name('tracking');
Route::get('/contactus','SiteController@contactus')->name('contactus');
Route::get('/blog','SiteController@blog')->name('blog');





// ======== UserController ======
Route::get('/profile','UserController@profile')->name('profile');
Route::get('/register','UserController@register')->name('register');
Route::get('/login','UserController@login')->name('login');









