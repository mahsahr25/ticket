<!DOCTYPE html>
<html lang="en">

<head>
    @include('layouts.confer.partials.head')
</head>

<body>


        @include('layouts.confer.partials.header')



         @yield('content')


  @include('layouts.confer.partials.footer')

  @include('layouts.confer.partials.footer-scripts')
</body>

</html>
