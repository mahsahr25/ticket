@extends('layouts.confer.sitemaster')

@section('content')
<!-- Main Area Start -->
<section class="our-speaker-area section-padding-100">
    <div class="container">

        <!-- === Final Ticket Area -->
        <div class="row my-5 text-center">

            <div class="col-11 border shadow pt-4">
                <div class="col-12  pt-4 ">
                    <p align="right">نام
                        رویداد</p>
                    <p align="right">سه شنبه - ساعت 17</p>
                    <p align="right">سینما آزادی - سالن 1</p>
                    <p align="right">جایگاه 2</p>

                    <p align="right">ردیف
                        3 - صندلی 1</p>

                    <p align="right">شماره پیگیری : 13895</p>

                </div>
                <div><b>
                        <hr></b></div>
                <div class="col-12  pt-4 ">
                    <p align="right">نام
                        رویداد</p>
                    <p align="right">
                        سه شنبه - ساعت 17</p>
                    <p align="right">سینما آزادی - سالن 1</p>
                    <p align="right">جایگاه 2</p>

                    <p align="right">ردیف
                        3 - صندلی 2</p>


                    <p align="right"> شماره پیگیری : 13895</p>

                </div>

            </div>



        </div>
        <!-- ==== End of Final Ticket Area ==== -->


    </div>
</section>


@endsection
