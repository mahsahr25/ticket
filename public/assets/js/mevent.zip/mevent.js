console.log('hi');



$(".mslider").owlCarousel({
    // autoplay:true,
    items:3,
    loop:true,
    rtl:true,
    dots:false,
    margin:10,
    nav: true,
    navText:['<','>'],
    // navColor:['#df42b1'],
    navClass:['owl-prev','owl-next'],
    nacElement:'div',
    center: true,
    // responsive:{
    //     0:{
    //         items:1
    //     },
    //     600:{
    //         items:3
    //     },
    //     1000:{
    //         items:12
    //     }
    // }
    // autoplayHoverPause:true,

    }
 );
//  $(".mslider").owlCarousel({
//     // autoplay:true,
//     items:3,
//     loop:true,
//     rtl:true,
//     // dots:true,
//     margin:10,
//     // nav: true,
//     center: true,
//     // autoplayHoverPause:true,

//     }
//  );
